            <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="admin_sidebarmenu">
                    <ul>
                        <li><a href="insert_post.php"><i class="fa fa-location-arrow"></i>  Insert New Course</a></li>

                        <li><a href="view_post.php?view=view_post"><i class="fa fa-cube"></i>  View All Course</a></li>
                        <li><a href="insert_slider.php"><i class="fa fa-leaf"></i>  Insert Homepage Slider</a></li>
                        
                        <li><a href="insert_slider.php"><i class="fa fa-file-picture-o"></i>  View All Homepage Slides</a></li>
                        <li><a href="insert_category.php"><i class="fa fa-black-tie"></i>  Add New Category</a></li>
                        <li><a href="view_categories.php"><i class="fa fa-diamond"></i>  View All Categories</a></li>
                        <li><a href="all_instructors.php"><i class="fa fa-adjust"></i>  All Instructors</a></li>  
                        <li><a href="all_learners.php"><i class="fa fa-adjust"></i>  All Learners</a></li>  
                    </ul>
                </div>
            </div>