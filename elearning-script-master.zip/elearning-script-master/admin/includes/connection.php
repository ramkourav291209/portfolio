<?php
$con = mysqli_connect('localhost','root','','elearning') or die('Error Establishing Database Connection!!');
?>