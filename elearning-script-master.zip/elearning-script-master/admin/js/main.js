$(document).ready(function(){
    $('.bxslider').bxSlider({
      mode: 'fade' 
    });
});